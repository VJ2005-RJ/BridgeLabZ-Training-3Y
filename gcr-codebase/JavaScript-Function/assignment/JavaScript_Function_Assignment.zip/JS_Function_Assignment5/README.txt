JavaScript Function Assignment 5 - Solutions

This folder contains one JavaScript file for each question (Q1-Q9).

Run any file using Node.js from this folder, for example:
node Q1_Callback_Flow.js

The files use core JavaScript and include short explanations where the assignment asks for them.

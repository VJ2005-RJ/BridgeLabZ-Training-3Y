JavaScript Classes Assignment 4 - Solutions

Contains separate solutions for Q1-Q9 from the uploaded assignment.

JavaScript files:
- Run with Node.js, for example: node Q1_Ecommerce_Product_Manager.js

HTML files:
- Open the .html files in a web browser to test the forms and DOM behavior.

Only core JavaScript (ES6+) is used. No external libraries or frameworks are required.

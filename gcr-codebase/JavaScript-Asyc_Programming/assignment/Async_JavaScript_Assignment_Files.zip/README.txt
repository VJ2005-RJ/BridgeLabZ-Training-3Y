ASSIGNMENT 6 — ASYNC PROGRAMMING WITH JAVASCRIPT

Files:
Q1 through Q10 are provided as separate JavaScript files, as required by the assignment.

Instructions:
1. Install Node.js for questions Q1–Q5 and Q7–Q10.
2. Open a terminal in this folder.
3. Run a file with: node Q1_async_coffee_maker.js
4. Q6 uses fetch() and is intended for a browser console or an HTML page.
5. Random failures are intentional; run a file more than once to see both success and failure paths.
6. Q5 runs the callback and async/await demonstrations independently, so their log messages can interleave.

All examples use core JavaScript (ES6+) without frameworks.

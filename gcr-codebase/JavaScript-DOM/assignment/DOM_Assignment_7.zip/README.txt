DOM ASSIGNMENT 7
================

This assignment contains 9 small projects based on the supplied assignment sheet.

HOW TO RUN
1. Extract this ZIP file.
2. Open any question's HTML file in a browser.
3. Its matching JavaScript file is linked at the bottom of the HTML file.
4. You can also run the JavaScript in a browser console after opening its HTML page.

FILES
- Q1_Product_List.html / Q1_Product_List.js
- Q2_Character_Counter.html / Q2_Character_Counter.js
- Q3_Multi_Step_Form.html / Q3_Multi_Step_Form.js
- Q4_Theme_Switcher.html / Q4_Theme_Switcher.js
- Q5_Image_Gallery.html / Q5_Image_Gallery.js
- Q6_Table_Filter.html / Q6_Table_Filter.js
- Q7_Mouse_Tracker.html / Q7_Mouse_Tracker.js
- Q8_Custom_Dropdown.html / Q8_Custom_Dropdown.js
- Q9_Form_Validation.html / Q9_Form_Validation.js

The code uses plain HTML, CSS and core JavaScript (ES6+), without frameworks.

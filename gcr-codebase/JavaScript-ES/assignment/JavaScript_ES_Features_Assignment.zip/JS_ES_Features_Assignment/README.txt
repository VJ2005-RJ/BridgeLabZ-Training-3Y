JavaScript ES Features Assignment (Questions 1–10)

How to run:
1. Install Node.js if it is not already installed.
2. Open a terminal in this folder.
3. Run a file with: node Q1_Dynamic_Data_Parser.js
4. For Q6, optionally provide the number of rows: node Q6_Pyramid_Pattern_Generator.js 7

Each question is in a separate JavaScript file. Outputs are printed using console.log().
Debugging observations are included as brief comments where the assignment asks for debugger use.
